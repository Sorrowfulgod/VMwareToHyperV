# Add all back compat aliases here
#
# Generic Example:
# New-Alias OldCmdletName NewCmdletName
#
# Specific Example:
# New-Alias New-VM New-SCVirtualMachine
#
#

## Connection Commandlets ##
New-Alias Get-VMMServer                   Get-SCVMMServer
New-Alias Set-VMMserver                   Set-SCVMMServer
New-Alias Backup-VMMServer                Backup-SCVMMServer

## Library Commandlets ##

New-Alias Add-LibraryServer               Add-SCLibraryServer
New-Alias Add-LibraryShare                Add-SCLibraryShare
New-Alias Get-LibraryServer               Get-SCLibraryServer
New-Alias Get-LibraryShare                Get-SCLibraryShare
New-Alias Set-LibraryServer               Set-SCLibraryServer
New-Alias Set-LibraryShare                Set-SCLibraryShare
New-Alias Remove-LibraryServer            Remove-SCLibraryServer
New-Alias Remove-LibraryShare             Remove-SCLibraryShare
New-Alias Discover-LibraryShare           Find-SCLibraryShare
New-Alias Refresh-LibraryShare            Read-SCLibraryShare
New-Alias Get-DirectoryChildItem          Get-SCDirectoryChildItem

New-Alias New-VM                          New-SCVirtualMachine
New-Alias New-Template                    New-SCVMTemplate
New-Alias New-HardwareProfile             New-SCHardwareProfile
New-Alias New-GuestOSProfile              New-SCGuestOSProfile

New-Alias Get-DependentLibraryObject      Get-SCDependentLibraryResource
New-Alias Get-VM                          Get-SCVirtualMachine
New-Alias Get-ISO                         Get-SCISO
New-Alias Get-Script                      Get-SCScript
New-Alias Get-Template                    Get-SCVMTemplate
New-Alias Get-VirtualFloppyDisk           Get-SCVirtualFloppyDisk
New-Alias Get-VirtualHardDisk             Get-SCVirtualHardDisk
New-Alias Get-OperatingSystem             Get-SCOperatingSystem
New-Alias Get-HardwareProfile             Get-SCHardwareProfile
New-Alias Get-GuestOSProfile              Get-SCGuestOSProfile
New-Alias Get-CPUType                     Get-SCCPUType

New-Alias Set-VM                          Set-SCVirtualMachine
New-Alias Set-ISO                         Set-SCISO
New-Alias Set-Script                      Set-SCScript
New-Alias Set-Template                    Set-SCVMTemplate
New-Alias Set-VirtualFloppyDisk           Set-SCVirtualFloppyDisk
New-Alias Set-VirtualHardDisk             Set-SCVirtualHardDisk
New-Alias Set-HardwareProfile             Set-SCHardwareProfile
New-Alias Set-GuestOSProfile              Set-SCGuestOSProfile

New-Alias Remove-VM                       Remove-SCVirtualMachine
New-Alias Remove-ISO                      Remove-SCISO
New-Alias Remove-Script                   Remove-SCScript
New-Alias Remove-Template                 Remove-SCVMTemplate
New-Alias Remove-VirtualFloppyDisk        Remove-SCVirtualFloppyDisk
New-Alias Remove-VirtualHardDisk          Remove-SCVirtualHardDisk
New-Alias Remove-HardwareProfile          Remove-SCHardwareProfile
New-Alias Remove-GuestOSProfile           Remove-SCGuestOSProfile

New-Alias Move-VirtualHardDisk            Move-SCVirtualHardDisk

## V2V CommandLets ##

New-Alias Copy-VMDK                       Copy-SCVirtualHardDisk



New-Alias New-VMXMachineConfig            New-SCVMXComputerConfiguration
New-Alias Get-VMXMachineConfig            Get-SCVMXComputerConfiguration
New-Alias Remove-VMXMachineConfig         Remove-SCVMXComputerConfiguration

New-Alias New-V2V                         New-SCV2V

## Host Cmdlets ##
#
New-Alias Add-VMHost                      Add-SCVMHost
New-Alias Get-VMHost                      Get-SCVMHost
New-Alias Set-VMHost                      Set-SCVMHost
New-Alias Remove-VMHost                   Remove-SCVMHost
New-Alias Refresh-VMHost                  Read-SCVMHost
New-Alias Associate-VMHost                Register-SCVMHost
New-Alias Enable-VMHost                   Enable-SCVMHost
New-Alias Disable-VMHost                  Disable-SCVMHost
New-Alias Move-VMHost                     Move-SCVMHost
New-Alias Get-VirtualizationManager       Get-SCVirtualizationManager
New-Alias Add-VirtualizationManager       Add-SCVirtualizationManager
New-Alias Set-VirtualizationManager       Set-SCVirtualizationManager
New-Alias Refresh-VirtualizationManager   Read-SCVirtualizationManager
New-Alias Remove-VirtualizationManager    Remove-SCVirtualizationManager
New-Alias Get-Certificate                 Get-SCCertificate

#
New-Alias New-VMHostGroup                 New-SCVMHostGroup
New-Alias Get-VMHostGroup                 Get-SCVMHostGroup
New-Alias Set-VMHostGroup                 Set-SCVMHostGroup
New-Alias Remove-VMHostGroup              Remove-SCVMHostGroup
New-Alias Move-VMHostGroup                Move-SCVMHostGroup
#
New-Alias Get-VMMManagedComputer          Get-SCVMMManagedComputer
New-Alias Update-VMMManagedComputer       Update-SCVMMManagedComputer
New-Alias Reassociate-VMMManagedComputer  Register-SCVMMManagedComputer
#
New-Alias Discover-Computer               Find-SCComputer
New-Alias Discover-Cluster                Find-SCCluster
#

## Storage Cmdlets ##
#
New-Alias Get-VMHostVolume                Get-SCStorageVolume
New-Alias Set-VMHostVolume                Set-SCStorageVolume
New-Alias Get-VMHostDisk                  Get-SCStorageDisk

# Host Network Adapter
New-Alias Add-VMHostNetworkAdapter        Add-SCVMHostNetworkAdapter
New-Alias Get-VMHostNetworkAdapter        Get-SCVMHostNetworkAdapter
New-Alias Set-VMHostNetworkAdapter        Set-SCVMHostNetworkAdapter 
New-Alias Remove-VMHostNetworkAdapter     Remove-SCVMHostNetworkAdapter 

# Virtual Network
New-Alias New-VirtualNetwork              New-SCVirtualNetwork
New-Alias Get-VirtualNetwork              Get-SCVirtualNetwork 
New-Alias Set-VirtualNetwork              Set-SCVirtualNetwork 
New-Alias Remove-VirtualNetwork           Remove-SCVirtualNetwork  

#Logical Network
New-Alias Get-NetworkLocation             Get-SCLogicalNetwork

#MAC Address
New-Alias New-PhysicalAddress             Grant-SCMACAddress

# Virtual Network Adapter
New-Alias New-VirtualNetworkAdapter       New-SCVirtualNetworkAdapter
New-Alias Get-VirtualNetworkAdapter       Get-SCVirtualNetworkAdapter 
New-Alias Set-VirtualNetworkAdapter       Set-SCVirtualNetworkAdapter 
New-Alias Remove-VirtualNetworkAdapter    Remove-SCVirtualNetworkAdapter 

## PRO cmdlets ##
New-Alias Get-PROTip                      Get-SCPROTip
New-Alias Set-PROTip                      Set-SCPROTip
New-Alias Invoke-PROTip                   Invoke-SCPROTip
New-Alias Dismiss-PROTip                  Clear-SCPROTip

## User Role cmdlets ##
New-Alias Get-VMMUserRole                 Get-SCUserRole
New-Alias New-VMMUserRole                 New-SCUserRole
New-Alias Set-VMMUserRole                 Set-SCUserRole
New-Alias Remove-VMMUserRole              Remove-SCUserRole

## Placement cmdlets ##
New-Alias Get-VMHostRating                Get-SCVMHostRating
New-Alias Get-LibraryRating               Get-SCLibraryRating


## Job cmdlets ##
New-Alias Get-Step                        Get-SCStep
New-Alias Restart-Job                     Restart-SCJob
New-Alias Stop-Job                        Stop-SCJob

## WLC Cmdlets ##
#

# Virtual Disk Drive cmdlets 
New-Alias Compress-VirtualDiskDrive       Compress-SCVirtualDiskDrive
New-Alias Convert-VirtualDiskDrive        Convert-SCVirtualDiskDrive
New-Alias Expand-VirtualDiskDrive         Expand-SCVirtualDiskDrive
New-Alias Remove-VirtualDiskDrive         Remove-SCVirtualDiskDrive
New-Alias Get-VirtualDiskDrive            Get-SCVirtualDiskDrive
New-Alias New-VirtualDiskDrive            New-SCVirtualDiskDrive
New-Alias Set-VirtualDiskDrive            Set-SCVirtualDiskDrive

# Virtual COM Port cmdlets
New-Alias Get-VirtualCOMPort              Get-SCVirtualCOMPort
New-Alias Set-VirtualCOMPort              Set-SCVirtualCOMPort

# Virtual DVD Drive cmdlets
New-Alias Get-VirtualDVDDrive             Get-SCVirtualDVDDrive
New-Alias New-VirtualDVDDrive             New-SCVirtualDVDDrive
New-Alias Remove-VirtualDVDDrive          Remove-SCVirtualDVDDrive
New-Alias Set-VirtualDVDDrive             Set-SCVirtualDVDDrive

# Virtual Floppy Drive cmdlets
New-Alias Get-VirtualFloppyDrive          Get-SCVirtualFloppyDrive
New-Alias Set-VirtualFloppyDrive          Set-SCVirtualFloppyDrive

# Virtual Scsi Adapter cmdlets
New-Alias Get-VirtualSCSIAdapter          Get-SCVirtualSCSIAdapter
New-Alias New-VirtualSCSIAdapter          New-SCVirtualSCSIAdapter
New-Alias Set-VirtualSCSIAdapter          Set-SCVirtualSCSIAdapter
New-Alias Remove-VirtualSCSIAdapter       Remove-SCVirtualSCSIAdapter

# VM Checkpoint cmdlets
New-Alias New-VMCheckpoint                New-SCVMCheckpoint
New-Alias Get-VMCheckpoint                Get-SCVMCheckpoint
New-Alias Set-VMCheckpoint                Set-SCVMCheckpoint
New-Alias Remove-VMCheckpoint             Remove-SCVMCheckpoint
New-Alias Restore-VMCheckpoint            Restore-SCVMCheckpoint
New-Alias Merge-VMCheckpoint              Remove-SCVMCheckpoint

# VMware cmdlets
New-Alias Get-VMwareResourcePool          Get-SCVMwareResourcePool

# VM Action Cmdlets
New-Alias Move-VM                         Move-SCVirtualMachine
New-Alias Refresh-VM                      Read-SCVirtualMachine
New-Alias Register-VM                     Register-SCVirtualMachine
New-Alias Repair-VM                       Repair-SCVirtualMachine
New-Alias Reset-VM                        Reset-SCVirtualMachine
New-Alias Resume-VM                       Resume-SCVirtualMachine
New-Alias Store-VM                        Save-SCVirtualMachine
New-Alias Stop-VM                         Use-SCStopVM
New-Alias Start-VM                        Start-SCVirtualMachine
New-Alias Suspend-VM                      Suspend-SCVirtualMachine
New-Alias Shutdown-VM				      Use-SCShutdownVM
New-Alias SaveState-VM				      Use-SCSaveStateVM
New-Alias DiscardSavedState-VM			  Use-SCDiscardSavedStateVM

# Clustering cmdlets
New-Alias Add-VMHostCluster               Add-SCVMHostCluster
New-Alias Get-VMHostCluster               Get-SCVMHostCluster
New-Alias Move-VMHostCluster              Move-SCVMHostCluster
New-Alias Refresh-VMHostCluster           Read-SCVMHostCluster
New-Alias Remove-VMHostCluster            Remove-SCVMHostCluster
New-Alias Set-VMHostCluster               Set-SCVMHostCluster

New-Alias Get-SCNotifications             Get-SCNotification
New-Alias Set-SCNotifications             Set-SCNotification
New-Alias Get-SCTags                      Get-SCTag

# SIG # Begin signature block
# MIId2wYJKoZIhvcNAQcCoIIdzDCCHcgCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUTbEDnkna88qdkY6ZCYNcQDm6
# bdugghhkMIIEwzCCA6ugAwIBAgITMwAAAKxjFufjRlWzHAAAAAAArDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwNTAzMTcxMzIz
# WhcNMTcwODAzMTcxMzIzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkMwRjQtMzA4Ni1ERUY4MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnyHdhNxySctX
# +G+LSGICEA1/VhPVm19x14FGBQCUqQ1ATOa8zP1ZGmU6JOUj8QLHm4SAwlKvosGL
# 8o03VcpCNsN+015jMXbhhP7wMTZpADTl5Ew876dSqgKRxEtuaHj4sJu3W1fhJ9Yq
# mwep+Vz5+jcUQV2IZLBw41mmWMaGLahpaLbul+XOZ7wi2+qfTrPVYpB3vhVMwapL
# EkM32hsOUfl+oZvuAfRwPBFxY/Gm0nZcTbB12jSr8QrBF7yf1e/3KSiqleci3GbS
# ZT896LOcr7bfm5nNX8fEWow6WZWBrI6LKPx9t3cey4tz0pAddX2N6LASt3Q0Hg7N
# /zsgOYvrlwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFCFXLAHtg1Boad3BTWmrjatP
# lDdiMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAEY2iloCmeBNdm4IPV1pQi7f4EsNmotUMen5D8Dg4rOLE9Jk
# d0lNOL5chmWK+d9BLG5SqsP0R/gqph4hHFZM4LVHUrSxQcQLWBEifrM2BeN0G6Yp
# RiGB7nnQqq86+NwX91pLhJ5LBzJo+EucWFKFmEBXLMBL85fyCusCk0RowdHpqh5s
# 3zhkMgjFX+cXWzJXULfGfEPvCXDKIgxsc5kUalYie/mkCKbpWXEW6gN+FNPKTbvj
# HcCxtcf9mVeqlA5joTFe+JbMygtOTeX0Mlf4rTvCrf3kA0zsRJL/y5JdihdxSP8n
# KX5H0Q2CWmDDY+xvbx9tLeqs/bETpaMz7K//Af4wggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TCCBhAwggP4
# oAMCAQICEzMAAABkR4SUhttBGTgAAAAAAGQwDQYJKoZIhvcNAQELBQAwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMTAeFw0xNTEwMjgyMDMxNDZaFw0xNzAx
# MjgyMDMxNDZaMIGDMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQDExVNaWNyb3NvZnQgQ29ycG9yYXRpb24w
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCTLtrY5j6Y2RsPZF9NqFhN
# FDv3eoT8PBExOu+JwkotQaVIXd0Snu+rZig01X0qVXtMTYrywPGy01IVi7azCLiL
# UAvdf/tqCaDcZwTE8d+8dRggQL54LJlW3e71Lt0+QvlaHzCuARSKsIK1UaDibWX+
# 9xgKjTBtTTqnxfM2Le5fLKCSALEcTOLL9/8kJX/Xj8Ddl27Oshe2xxxEpyTKfoHm
# 5jG5FtldPtFo7r7NSNCGLK7cDiHBwIrD7huTWRP2xjuAchiIU/urvzA+oHe9Uoi/
# etjosJOtoRuM1H6mEFAQvuHIHGT6hy77xEdmFsCEezavX7qFRGwCDy3gsA4boj4l
# AgMBAAGjggF/MIIBezAfBgNVHSUEGDAWBggrBgEFBQcDAwYKKwYBBAGCN0wIATAd
# BgNVHQ4EFgQUWFZxBPC9uzP1g2jM54BG91ev0iIwUQYDVR0RBEowSKRGMEQxDTAL
# BgNVBAsTBE1PUFIxMzAxBgNVBAUTKjMxNjQyKzQ5ZThjM2YzLTIzNTktNDdmNi1h
# M2JlLTZjOGM0NzUxYzRiNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2oynUC
# lTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# b3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsGAQUF
# BwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwGA1Ud
# EwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjiDGRDHd1crow7hSS1nUDWvWas
# W1c12fToOsBFmRBN27SQ5Mt2UYEJ8LOTTfT1EuS9SCcUqm8t12uD1ManefzTJRtG
# ynYCiDKuUFT6A/mCAcWLs2MYSmPlsf4UOwzD0/KAuDwl6WCy8FW53DVKBS3rbmdj
# vDW+vCT5wN3nxO8DIlAUBbXMn7TJKAH2W7a/CDQ0p607Ivt3F7cqhEtrO1Rypehh
# bkKQj4y/ebwc56qWHJ8VNjE8HlhfJAk8pAliHzML1v3QlctPutozuZD3jKAO4WaV
# qJn5BJRHddW6l0SeCuZmBQHmNfXcz4+XZW/s88VTfGWjdSGPXC26k0LzV6mjEaEn
# S1G4t0RqMP90JnTEieJ6xFcIpILgcIvcEydLBVe0iiP9AXKYVjAPn6wBm69FKCQr
# IPWsMDsw9wQjaL8GHk4wCj0CmnixHQanTj2hKRc2G9GL9q7tAbo0kFNIFs0EYkbx
# Cn7lBOEqhBSTyaPS6CvjJZGwD0lNuapXDu72y4Hk4pgExQ3iEv/Ij5oVWwT8okie
# +fFLNcnVgeRrjkANgwoAyX58t0iqbefHqsg3RGSgMBu9MABcZ6FQKwih3Tj0DVPc
# gnJQle3c6xN3dZpuEgFcgJh/EyDXSdppZzJR4+Bbf5XA/Rcsq7g7X7xl4bJoNKLf
# cafOabJhpxfcFOowMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEw
# HhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBT
# aWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# q/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2Avw
# OMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eW
# WcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1
# eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le
# 2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+
# 0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2
# zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv
# 1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLn
# JN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31n
# gOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+Hgg
# WCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAG
# CSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZ
# BgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/
# BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8E
# UzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEB
# BFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcw
# gZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwIC
# MDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBu
# AHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOS
# mUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQ
# VdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQ
# dION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive
# /DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrC
# xq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/
# E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ
# 7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANah
# Rr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3
# S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1W
# Tk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1t
# bWrJUnMTDXpQzTGCBOEwggTdAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcg
# UENBIDIwMTECEzMAAABkR4SUhttBGTgAAAAAAGQwCQYFKw4DAhoFAKCB9TAZBgkq
# hkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGC
# NwIBFTAjBgkqhkiG9w0BCQQxFgQUA8iXqJFdzWR9cZQYpnU3kchxmXgwgZQGCisG
# AQQBgjcCAQwxgYUwgYKgVoBUAFMAeQBzAHQAZQBtACAAQwBlAG4AdABlAHIAIAAy
# ADAAMQA2ACAAVgBpAHIAdAB1AGEAbAAgAE0AYQBjAGgAaQBuAGUAIABNAGEAbgBh
# AGcAZQByoSiAJmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9TeXN0ZW1jZW50ZXIg
# MA0GCSqGSIb3DQEBAQUABIIBAHvUgih6ZnMbuqNw8iA+a+i4ZdSnIplzwCJFH3D7
# RVPALcqj01bxgEwQJEWNsG1mVnZ1srVTqTM8hEBq2pMhGu8y5wzJun7aaUFivWAj
# wt7breUJxS5jmiGjepjbO69t6zNuYTW7l6Ky/WxSQXVRax4VbGIv4jTdgRWmc5aT
# iiqcpdi+wqueaUCiax+gqFdxBoGXm87z2/Ue4hbjXcWm1d1bNSpcmSYXxMKyQq2I
# kR7QOJUbHKVBsSWbUODRiHS1Ry/Q5IsevxsEfIWWzh6TNP5bSbs104F0JFMjspRB
# N9bJqHZdMS3DOvd+7kv4gSmQiUpqoF8wPrDsUzK/iMDjm7GhggIoMIICJAYJKoZI
# hvcNAQkGMYICFTCCAhECAQEwgY4wdzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBAhMz
# AAAArGMW5+NGVbMcAAAAAACsMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJ
# KoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0xNjA5MTUxMjA0NTJaMCMGCSqGSIb3
# DQEJBDEWBBQxFmxr98EMApwXVDNvGRrveWM/pzANBgkqhkiG9w0BAQUFAASCAQBi
# wvgXh2BTb7zfXKKh+5RrSKR+orkP1p3U5MTh21fdbC6c5ZodvXjVDgT6oq1wbFkO
# 0S/5tqM0lwLkxLrL0FVtVISSgixyxQtLHI8uozlJd9b9itb4/kl4ZbNGm5WbIe4z
# gz1kk1x1sM8Fe5qC+iOvUUjepiCsxLAp+Vl3M7cGhG841Ar334eKze9aC7giaKGh
# gujIROt1FmbTSPYuG7IpVbM688MtMnqPBYHN8vH10VPdlueberYsKEE9qSr7YA35
# 3OjJB1yqsbooKRBn6PqY/gbvBFEbA0oIvkLze70Pw6FLVIrAfJAYI72dlGSXLcOe
# 6N5GDmj6XJVQpB1Nqx4/
# SIG # End signature block
