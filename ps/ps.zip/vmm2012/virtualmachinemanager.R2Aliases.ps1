# Add all back compat aliases here
#
# Generic Example:
# New-Alias OldCmdletName NewCmdletName
#
# Specific Example:
# New-Alias New-VM New-SCVirtualMachine
#
#

## Connection Commandlets ##
New-Alias Get-VMMServer                   Get-SCVMMServer
New-Alias Set-VMMserver                   Set-SCVMMServer
New-Alias Backup-VMMServer                Backup-SCVMMServer

## Library Commandlets ##

New-Alias Add-LibraryServer               Add-SCLibraryServer
New-Alias Add-LibraryShare                Add-SCLibraryShare
New-Alias Get-LibraryServer               Get-SCLibraryServer
New-Alias Get-LibraryShare                Get-SCLibraryShare
New-Alias Set-LibraryServer               Set-SCLibraryServer
New-Alias Set-LibraryShare                Set-SCLibraryShare
New-Alias Remove-LibraryServer            Remove-SCLibraryServer
New-Alias Remove-LibraryShare             Remove-SCLibraryShare
New-Alias Discover-LibraryShare           Find-SCLibraryShare
New-Alias Refresh-LibraryShare            Read-SCLibraryShare
New-Alias Get-DirectoryChildItem          Get-SCDirectoryChildItem

New-Alias New-VM                          New-SCVirtualMachine
New-Alias New-Template                    New-SCVMTemplate
New-Alias New-HardwareProfile             New-SCHardwareProfile
New-Alias New-GuestOSProfile              New-SCGuestOSProfile

New-Alias Get-DependentLibraryObject      Get-SCDependentLibraryResource
New-Alias Get-VM                          Get-SCVirtualMachine
New-Alias Get-ISO                         Get-SCISO
New-Alias Get-Script                      Get-SCScript
New-Alias Get-Template                    Get-SCVMTemplate
New-Alias Get-VirtualFloppyDisk           Get-SCVirtualFloppyDisk
New-Alias Get-VirtualHardDisk             Get-SCVirtualHardDisk
New-Alias Get-OperatingSystem             Get-SCOperatingSystem
New-Alias Get-HardwareProfile             Get-SCHardwareProfile
New-Alias Get-GuestOSProfile              Get-SCGuestOSProfile
New-Alias Get-CPUType                     Get-SCCPUType

New-Alias Set-VM                          Set-SCVirtualMachine
New-Alias Set-ISO                         Set-SCISO
New-Alias Set-Script                      Set-SCScript
New-Alias Set-Template                    Set-SCVMTemplate
New-Alias Set-VirtualFloppyDisk           Set-SCVirtualFloppyDisk
New-Alias Set-VirtualHardDisk             Set-SCVirtualHardDisk
New-Alias Set-HardwareProfile             Set-SCHardwareProfile
New-Alias Set-GuestOSProfile              Set-SCGuestOSProfile

New-Alias Remove-VM                       Remove-SCVirtualMachine
New-Alias Remove-ISO                      Remove-SCISO
New-Alias Remove-Script                   Remove-SCScript
New-Alias Remove-Template                 Remove-SCVMTemplate
New-Alias Remove-VirtualFloppyDisk        Remove-SCVirtualFloppyDisk
New-Alias Remove-VirtualHardDisk          Remove-SCVirtualHardDisk
New-Alias Remove-HardwareProfile          Remove-SCHardwareProfile
New-Alias Remove-GuestOSProfile           Remove-SCGuestOSProfile

New-Alias Move-VirtualHardDisk            Move-SCVirtualHardDisk

## V2V CommandLets ##

New-Alias Copy-VMDK                       Copy-SCVirtualHardDisk



New-Alias New-VMXMachineConfig            New-SCVMXComputerConfiguration
New-Alias Get-VMXMachineConfig            Get-SCVMXComputerConfiguration
New-Alias Remove-VMXMachineConfig         Remove-SCVMXComputerConfiguration

New-Alias New-V2V                         New-SCV2V

## Host Cmdlets ##
#
New-Alias Add-VMHost                      Add-SCVMHost
New-Alias Get-VMHost                      Get-SCVMHost
New-Alias Set-VMHost                      Set-SCVMHost
New-Alias Remove-VMHost                   Remove-SCVMHost
New-Alias Refresh-VMHost                  Read-SCVMHost
New-Alias Associate-VMHost                Register-SCVMHost
New-Alias Enable-VMHost                   Enable-SCVMHost
New-Alias Disable-VMHost                  Disable-SCVMHost
New-Alias Move-VMHost                     Move-SCVMHost
New-Alias Get-VirtualizationManager       Get-SCVirtualizationManager
New-Alias Add-VirtualizationManager       Add-SCVirtualizationManager
New-Alias Set-VirtualizationManager       Set-SCVirtualizationManager
New-Alias Refresh-VirtualizationManager   Read-SCVirtualizationManager
New-Alias Remove-VirtualizationManager    Remove-SCVirtualizationManager
New-Alias Get-Certificate                 Get-SCCertificate

#
New-Alias New-VMHostGroup                 New-SCVMHostGroup
New-Alias Get-VMHostGroup                 Get-SCVMHostGroup
New-Alias Set-VMHostGroup                 Set-SCVMHostGroup
New-Alias Remove-VMHostGroup              Remove-SCVMHostGroup
New-Alias Move-VMHostGroup                Move-SCVMHostGroup
#
New-Alias Get-VMMManagedComputer          Get-SCVMMManagedComputer
New-Alias Update-VMMManagedComputer       Update-SCVMMManagedComputer
New-Alias Reassociate-VMMManagedComputer  Register-SCVMMManagedComputer
#
New-Alias Discover-Computer               Find-SCComputer
New-Alias Discover-Cluster                Find-SCCluster
#

## Storage Cmdlets ##
#
New-Alias Get-VMHostVolume                Get-SCStorageVolume
New-Alias Set-VMHostVolume                Set-SCStorageVolume
New-Alias Get-VMHostDisk                  Get-SCStorageDisk

# Host Network Adapter
New-Alias Add-VMHostNetworkAdapter        Add-SCVMHostNetworkAdapter
New-Alias Get-VMHostNetworkAdapter        Get-SCVMHostNetworkAdapter
New-Alias Set-VMHostNetworkAdapter        Set-SCVMHostNetworkAdapter 
New-Alias Remove-VMHostNetworkAdapter     Remove-SCVMHostNetworkAdapter 

# Virtual Network
New-Alias New-VirtualNetwork              New-SCVirtualNetwork
New-Alias Get-VirtualNetwork              Get-SCVirtualNetwork 
New-Alias Set-VirtualNetwork              Set-SCVirtualNetwork 
New-Alias Remove-VirtualNetwork           Remove-SCVirtualNetwork  

#Logical Network
New-Alias Get-NetworkLocation             Get-SCLogicalNetwork

#MAC Address
New-Alias New-PhysicalAddress             Grant-SCMACAddress

# Virtual Network Adapter
New-Alias New-VirtualNetworkAdapter       New-SCVirtualNetworkAdapter
New-Alias Get-VirtualNetworkAdapter       Get-SCVirtualNetworkAdapter 
New-Alias Set-VirtualNetworkAdapter       Set-SCVirtualNetworkAdapter 
New-Alias Remove-VirtualNetworkAdapter    Remove-SCVirtualNetworkAdapter 

## PRO cmdlets ##
New-Alias Get-PROTip                      Get-SCPROTip
New-Alias Set-PROTip                      Set-SCPROTip
New-Alias Invoke-PROTip                   Invoke-SCPROTip
New-Alias Dismiss-PROTip                  Clear-SCPROTip

## User Role cmdlets ##
New-Alias Get-VMMUserRole                 Get-SCUserRole
New-Alias New-VMMUserRole                 New-SCUserRole
New-Alias Set-VMMUserRole                 Set-SCUserRole
New-Alias Remove-VMMUserRole              Remove-SCUserRole

## Placement cmdlets ##
New-Alias Get-VMHostRating                Get-SCVMHostRating
New-Alias Get-LibraryRating               Get-SCLibraryRating


## Job cmdlets ##
New-Alias Get-Job                         Get-SCJob
New-Alias Get-Step                        Get-SCStep
New-Alias Restart-Job                     Restart-SCJob
New-Alias Stop-Job                        Stop-SCJob

## WLC Cmdlets ##
#

# Virtual Disk Drive cmdlets 
New-Alias Compress-VirtualDiskDrive       Compress-SCVirtualDiskDrive
New-Alias Convert-VirtualDiskDrive        Convert-SCVirtualDiskDrive
New-Alias Expand-VirtualDiskDrive         Expand-SCVirtualDiskDrive
New-Alias Remove-VirtualDiskDrive         Remove-SCVirtualDiskDrive
New-Alias Get-VirtualDiskDrive            Get-SCVirtualDiskDrive
New-Alias New-VirtualDiskDrive            New-SCVirtualDiskDrive
New-Alias Set-VirtualDiskDrive            Set-SCVirtualDiskDrive

# Virtual COM Port cmdlets
New-Alias Get-VirtualCOMPort              Get-SCVirtualCOMPort
New-Alias Set-VirtualCOMPort              Set-SCVirtualCOMPort

# Virtual DVD Drive cmdlets
New-Alias Get-VirtualDVDDrive             Get-SCVirtualDVDDrive
New-Alias New-VirtualDVDDrive             New-SCVirtualDVDDrive
New-Alias Remove-VirtualDVDDrive          Remove-SCVirtualDVDDrive
New-Alias Set-VirtualDVDDrive             Set-SCVirtualDVDDrive

# Virtual Floppy Drive cmdlets
New-Alias Get-VirtualFloppyDrive          Get-SCVirtualFloppyDrive
New-Alias Set-VirtualFloppyDrive          Set-SCVirtualFloppyDrive

# Virtual Scsi Adapter cmdlets
New-Alias Get-VirtualSCSIAdapter          Get-SCVirtualSCSIAdapter
New-Alias New-VirtualSCSIAdapter          New-SCVirtualSCSIAdapter
New-Alias Set-VirtualSCSIAdapter          Set-SCVirtualSCSIAdapter
New-Alias Remove-VirtualSCSIAdapter       Remove-SCVirtualSCSIAdapter

# VM Checkpoint cmdlets
New-Alias New-VMCheckpoint                New-SCVMCheckpoint
New-Alias Get-VMCheckpoint                Get-SCVMCheckpoint
New-Alias Set-VMCheckpoint                Set-SCVMCheckpoint
New-Alias Remove-VMCheckpoint             Remove-SCVMCheckpoint
New-Alias Restore-VMCheckpoint            Restore-SCVMCheckpoint
New-Alias Merge-VMCheckpoint              Remove-SCVMCheckpoint

# VMware cmdlets
New-Alias Get-VMwareResourcePool          Get-SCVMwareResourcePool

# VM Action Cmdlets
New-Alias Move-VM                         Move-SCVirtualMachine
New-Alias Refresh-VM                      Read-SCVirtualMachine
New-Alias Register-VM                     Register-SCVirtualMachine
New-Alias Repair-VM                       Repair-SCVirtualMachine
New-Alias Reset-VM                        Reset-SCVirtualMachine
New-Alias Resume-VM                       Resume-SCVirtualMachine
New-Alias Store-VM                        Save-SCVirtualMachine
New-Alias Stop-VM                         Use-SCStopVM
New-Alias Start-VM                        Start-SCVirtualMachine
New-Alias Suspend-VM                      Suspend-SCVirtualMachine
New-Alias Shutdown-VM				      Use-SCShutdownVM
New-Alias SaveState-VM				      Use-SCSaveStateVM
New-Alias DiscardSavedState-VM			  Use-SCDiscardSavedStateVM

# Clustering cmdlets
New-Alias Add-VMHostCluster               Add-SCVMHostCluster
New-Alias Get-VMHostCluster               Get-SCVMHostCluster
New-Alias Move-VMHostCluster              Move-SCVMHostCluster
New-Alias Refresh-VMHostCluster           Read-SCVMHostCluster
New-Alias Remove-VMHostCluster            Remove-SCVMHostCluster
New-Alias Set-VMHostCluster               Set-SCVMHostCluster

New-Alias Get-SCNotifications             Get-SCNotification
New-Alias Set-SCNotifications             Set-SCNotification
New-Alias Get-SCTags                      Get-SCTag

# SIG # Begin signature block
# MIIbAwYJKoZIhvcNAQcCoIIa9DCCGvACAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUbPUC3KpToE3+pOntj+LuLckw
# UnGgghWCMIIEwzCCA6ugAwIBAgITMwAAAIgVUlHPFzd7VQAAAAAAiDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTUxMDA3MTgxNDAx
# WhcNMTcwMTA3MTgxNDAxWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OjdBRkEtRTQxQy1FMTQyMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyBEjpkOcrwAm
# 9WRMNBv90OUqsqL7/17OvrhGMWgwAsx3sZD0cMoNxrlfHwNfCNopwH0z7EI3s5gQ
# Z4Pkrdl9GjQ9/FZ5uzV24xfhdq/u5T2zrCXC7rob9FfhBtyTI84B67SDynCN0G0W
# hJaBW2AFx0Dn2XhgYzpvvzk4NKZl1NYi0mHlHSjWfaqbeaKmVzp9JSfmeaW9lC6s
# IgqKo0FFZb49DYUVdfbJI9ECTyFEtUaLWGchkBwj9oz62u9Kg6sh3+UslWTY4XW+
# 7bBsN3zC430p0X7qLMwQf+0oX7liUDuszCp828HsDb4pu/RRyv+KOehVKx91UNcr
# Dc9Z7isNeQIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFJQRxg5HoMTIdSZj1v3l1GjM
# 6KEMMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAHoudDDxFsg2z0Y+GhQ91SQW1rdmWBxJOI5OpoPzI7P7X2dU
# ouvkmQnysdipDYER0xxkCf5VAz+dDnSkUQeTn4woryjzXBe3g30lWh8IGMmGPWhq
# L1+dpjkxKbIk9spZRdVH0qGXbi8tqemmEYJUW07wn76C+wCZlbJnZF7W2+5g9MZs
# RT4MAxpQRw+8s1cflfmLC5a+upyNO3zBEY2gaBs1til9O7UaUD4OWE4zPuz79AJH
# 9cGBQo8GnD2uNFYqLZRx3T2X+AVt/sgIHoUSK06fqVMXn1RFSZT3jRL2w/tD5uef
# 4ta/wRmAStRMbrMWYnXAeCJTIbWuE2lboA3IEHIwggTsMIID1KADAgECAhMzAAAB
# Cix5rtd5e6asAAEAAAEKMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE1MDYwNDE3NDI0NVoXDTE2MDkwNDE3NDI0NVowgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJL8bza74QO5KNZG0aJhuqVG+2MWPi75R9LH7O3HmbEm
# UXW92swPBhQRpGwZnsBfTVSJ5E1Q2I3NoWGldxOaHKftDXT3p1Z56Cj3U9KxemPg
# 9ZSXt+zZR/hsPfMliLO8CsUEp458hUh2HGFGqhnEemKLwcI1qvtYb8VjC5NJMIEb
# e99/fE+0R21feByvtveWE1LvudFNOeVz3khOPBSqlw05zItR4VzRO/COZ+owYKlN
# Wp1DvdsjusAP10sQnZxN8FGihKrknKc91qPvChhIqPqxTqWYDku/8BTzAMiwSNZb
# /jjXiREtBbpDAk8iAJYlrX01boRoqyAYOCj+HKIQsaUCAwEAAaOCAWAwggFcMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSJ/gox6ibN5m3HkZG5lIyiGGE3
# NDBRBgNVHREESjBIpEYwRDENMAsGA1UECxMETU9QUjEzMDEGA1UEBRMqMzE1OTUr
# MDQwNzkzNTAtMTZmYS00YzYwLWI2YmYtOWQyYjFjZDA1OTg0MB8GA1UdIwQYMBaA
# FMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY0NvZFNpZ1BDQV8w
# OC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljQ29kU2lnUENBXzA4LTMx
# LTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQCmqFOR3zsB/mFdBlrrZvAM2PfZ
# hNMAUQ4Q0aTRFyjnjDM4K9hDxgOLdeszkvSp4mf9AtulHU5DRV0bSePgTxbwfo/w
# iBHKgq2k+6apX/WXYMh7xL98m2ntH4LB8c2OeEti9dcNHNdTEtaWUu81vRmOoECT
# oQqlLRacwkZ0COvb9NilSTZUEhFVA7N7FvtH/vto/MBFXOI/Enkzou+Cxd5AGQfu
# FcUKm1kFQanQl56BngNb/ErjGi4FrFBHL4z6edgeIPgF+ylrGBT6cgS3C6eaZOwR
# XU9FSY0pGi370LYJU180lOAWxLnqczXoV+/h6xbDGMcGszvPYYTitkSJlKOGMIIF
# vDCCA6SgAwIBAgIKYTMmGgAAAAAAMTANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZIm
# iZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQD
# EyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMTAwODMx
# MjIxOTMyWhcNMjAwODMxMjIyOTMyWjB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJyWVwZMGS/HZpgICBC
# mXZTbD4b1m/My/Hqa/6XFhDg3zp0gxq3L6Ay7P/ewkJOI9VyANs1VwqJyq4gSfTw
# aKxNS42lvXlLcZtHB9r9Jd+ddYjPqnNEf9eB2/O98jakyVxF3K+tPeAoaJcap6Vy
# c1bxF5Tk/TWUcqDWdl8ed0WDhTgW0HNbBbpnUo2lsmkv2hkL/pJ0KeJ2L1TdFDBZ
# +NKNYv3LyV9GMVC5JxPkQDDPcikQKCLHN049oDI9kM2hOAaFXE5WgigqBTK3S9dP
# Y+fSLWLxRT3nrAgA9kahntFbjCZT6HqqSvJGzzc8OJ60d1ylF56NyxGPVjzBrAlf
# A9MCAwEAAaOCAV4wggFaMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFMsR6MrS
# tBZYAck3LjMWFrlMmgofMAsGA1UdDwQEAwIBhjASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBT90TFO0yaKleGYYDuoMW+mPLzYLTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTAfBgNVHSMEGDAWgBQOrIJgQFYnl+UlE/wq4QpTlVnk
# pDBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEE
# SDBGMEQGCCsGAQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY3Jvc29mdFJvb3RDZXJ0LmNydDANBgkqhkiG9w0BAQUFAAOCAgEAWTk+
# fyZGr+tvQLEytWrrDi9uqEn361917Uw7LddDrQv+y+ktMaMjzHxQmIAhXaw9L0y6
# oqhWnONwu7i0+Hm1SXL3PupBf8rhDBdpy6WcIC36C1DEVs0t40rSvHDnqA2iA6VW
# 4LiKS1fylUKc8fPv7uOGHzQ8uFaa8FMjhSqkghyT4pQHHfLiTviMocroE6WRTsgb
# 0o9ylSpxbZsa+BzwU9ZnzCL/XB3Nooy9J7J5Y1ZEolHN+emjWFbdmwJFRC9f9Nqu
# 1IIybvyklRPk62nnqaIsvsgrEA5ljpnb9aL6EiYJZTiU8XofSrvR4Vbo0HiWGFzJ
# NRZf3ZMdSY4tvq00RBzuEBUaAF3dNVshzpjHCe6FDoxPbQ4TTj18KUicctHzbMrB
# 7HCjV5JXfZSNoBtIA1r3z6NnCnSlNu0tLxfI5nI3EvRvsTxngvlSso0zFmUeDord
# EN5k9G/ORtTTF+l5xAS00/ss3x+KnqwK+xMnQK3k+eGpf0a7B2BHZWBATrBC7E7t
# s3Z52Ao0CW0cgDEf4g5U3eWh++VHEK1kmP9QFi58vwUheuKVQSdpw5OPlcmN2Jsh
# rg1cnPCiroZogwxqLbt2awAdlq3yFnv2FoMkuYjPaqhHMS+a3ONxPdcAfmJH0c6I
# ybgY+g5yjcGjPa8CQGr/aZuW4hCoELQ3UAjWwz0wggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TGCBOswggTn
# AgEBMIGQMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAh
# BgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBAhMzAAABCix5rtd5e6as
# AAEAAAEKMAkGBSsOAwIaBQCgggEDMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBQ2
# 2WSBxdX8h8rqOQTZH+ExZNFIAjCBogYKKwYBBAGCNwIBDDGBkzCBkKBcgFoAUwB5
# AHMAdABlAG0AIABDAGUAbgB0AGUAcgAgADIAMAAxADIAIABSADIAIABWAGkAcgB0
# AHUAYQBsACAATQBhAGMAaABpAG4AZQAgAE0AYQBuAGEAZwBlAHKhMIAuaHR0cDov
# L2dvLm1pY3Jvc29mdC5jb20vZndsaW5rLz9MaW5rSWQ9MjU4NTM5IDANBgkqhkiG
# 9w0BAQEFAASCAQALNpJ5CSabvDe9LQobK2fb5sJswy+WHC1C2wLMzPtOe04HIwJk
# ksQ/f+gdhzyt35CqLnjil3VmbA5eDrVO2VJm8bBhe91eNHWLZ20NZ401sN9tO0qd
# GcZgILRhcl9bnac1kZllFvwVktcZSrVcMfXlGV2Q4g8sD9+KEFfeAbdcUyD72Zdy
# 2sxXla+YW50ihAdUFwqVWspJfvk+0/z+6ebdCsNc33yrU7KKseZ2QP0cc5cMLRt1
# Ypbf/vuh7xT4yT9iT7j0ltG8wvFbyX1aQ/fZR3chRww9YDFyP7b60PTdlCU2O9Gz
# qIh2XUPPjv9BZtrlaFi+FSS6Zfcv7rORAWb1oYICKDCCAiQGCSqGSIb3DQEJBjGC
# AhUwggIRAgEBMIGOMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xITAfBgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQQITMwAAAIgVUlHP
# Fzd7VQAAAAAAiDAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEH
# ATAcBgkqhkiG9w0BCQUxDxcNMTYwMTA5MjMyNjAxWjAjBgkqhkiG9w0BCQQxFgQU
# JMh0eKmVQF3dbJEkOluKP0RZnOQwDQYJKoZIhvcNAQEFBQAEggEAKlgXVHuZPmOc
# WNqTtDzl+NmpRTloY+T8oKbS4cxvJw5FwTx6JVCHK7H5ucnJ/Xmk8DqO+v+crGNP
# PBlfR215QSTVoClJoHcuTNu7y5JwWPYP8BR/w7nPthRmKtlT2yYD2mo9V/ElTgkg
# wPlXktPKv6PT4zQajN90v9cEX3aJcIPsTStX1WkBy7F+ol2xoMENPDQ/TZ5g4S3E
# Zo2ZD/rVl7fXO+dMnFgt/AFJViLFaf4wlKJK6ZydXLrQ/wdAth9A5IGwVG3gaCFk
# qace8Nrx0X8wJKIMQgoE8Y1+cICo4bJwfamKCaeflZ9xkXIVzjLnAt7GTeTpi32V
# ZgRp9BMfaA==
# SIG # End signature block
